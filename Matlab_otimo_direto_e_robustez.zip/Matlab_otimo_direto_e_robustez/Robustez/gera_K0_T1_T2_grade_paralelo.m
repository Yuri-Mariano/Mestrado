function [K0_atual,T1_atual,T2_atual] = gera_K0_T1_T2_grade_paralelo(K0,T1,T2,eps_atual,m,i_aval_tripl)
% Gera pontos numa grade do paralelep�pedo

% m = n�mero de pontos em cada aresta do paralelep�pedo
% Portanto, m^3 � o n�mero total de pontos.
% i_aval_tripl = ponto do paralelep�pedo (1 <= i_aval_tripl <= m^3)
% Valores-limites do paralelep�pedo (K0, T1,T2)

K0sup = (1+eps_atual)*K0;
K0inf = (1-eps_atual)*K0;
DK0 = (K0sup-K0inf)/(m-1);

T1sup = (1+eps_atual)*T1;
T1inf = (1-eps_atual)*T1;
DT1 = (T1sup-T1inf)/(m-1);

T2sup = (1+eps_atual)*T2;
T2inf = (1-eps_atual)*T2;
DT2 = (T2sup-T2inf)/(m-1);

m2 = m*m;
i = floor((i_aval_tripl-0.001)/m2);

K0_atual = K0inf+i*DK0;

j = i_aval_tripl-i*m2;
floor_j_m = floor((j-0.001)/m);

T2_atual = T2inf+floor_j_m*DT2;

k = j-floor_j_m*m;

T1_atual = T1inf+(k-1)*DT1;