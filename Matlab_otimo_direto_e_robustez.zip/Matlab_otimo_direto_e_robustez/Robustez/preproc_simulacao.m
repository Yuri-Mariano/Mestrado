function [tempo,potencia,tXu] = preproc_simulacao(tmin,umin,n)

%==========================================================================
%               MONTA A MATRIZ DE DADOS PARA O SIMULADOR
%==========================================================================

deltat = tmin/n;
tempo=[];
potencia=[];
tXu=[];
for i=1:n,
    tempo = [tempo; (i-1)*deltat; i*deltat];
    potencia = [potencia; umin(i); umin(i)];
end
tXu=[tempo potencia];