function [Kc,tauI,tauD] = PID_SIMC(K0,T1,T2,T)
% Esta fun��o calcula os par�metros do compensador PID-SIMC

Kc   = T1/(K0*2*T);
tauI = min([T1 8*T]);
tauD = T2;