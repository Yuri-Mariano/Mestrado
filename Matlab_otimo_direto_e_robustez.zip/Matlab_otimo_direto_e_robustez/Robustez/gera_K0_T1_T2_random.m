function [K0_atual,T1_atual,T2_atual] = gera_K0_T1_T2_random(K0,T1,T2,eps_atual)

% % Gera��o aleat�ria

K0_sup   = (1+eps_atual)*K0;
%K0_sup   = K0;
K0_inf   = (1-eps_atual)*K0;
K0_atual = K0_inf+rand*(K0_sup-K0_inf);
%K0_atual = K0_inf;

T1_sup   = (1+eps_atual)*T1;
T1_inf   = (1-eps_atual)*T1;
T1_atual = T1_inf+rand*(T1_sup-T1_inf);

T2_sup   = (1+eps_atual)*T2;
T2_inf   = (1-eps_atual)*T2;
T2_atual = T2_inf+rand*(T2_sup-T2_inf);