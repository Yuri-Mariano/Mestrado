function [tmin,umin,A,b,c]=tempo_minimo(K0,T1,T2,qmax,n,eps,teta2_desejado)

%==========================================================================
%                  MONTA AS MATRIZES DO MODELO DE ESTADOS
%==========================================================================

A = [0 1;
      -1/T1/T2 -(T1+T2)/T1/T2];
 
b = [0; K0/T1/T2];
  
c = [1 0];
    
%==========================================================================
%       INICIALIZA��O DO PROCESSO DE BUSCA DO TEMPO M�NIMO
%==========================================================================

% Chute inicial

tinf = 0.5*min([T1 T2]);    % Extremo inferior para a busca do tempo m�nimo
tsup = 10*max([T1 T2]);     % Extremo superior para a busca do tempo�m�nimo
tmeio = (tsup+tinf)/2;      % Ponto m�dio do intervalo de busca

[u,teta2max_inf]  = prog_lin(A,b,c,qmax,tinf,n);     % Calcula o alcance para o extremo inferior
[u,teta2max_sup]  = prog_lin(A,b,c,qmax,tsup,n);     % Calcula o alcance para o extremo superior
[u,teta2max_meio] = prog_lin(A,b,c,qmax,tmeio,n);    % Calcula o alcance para o ponto m�dio

%==========================================================================
%                   BUSCA BIN�RIA DO TEMPO M�NIMO
%==========================================================================

while abs(teta2max_meio-teta2_desejado) > eps,
    
    % Redefine o intervalo de busca
    if teta2max_meio > teta2_desejado
        tsup = tmeio;   % Novo intervalo de busca � [tinf, tmeio]
    else
        tinf = tmeio;   % Novo intervalo de busca � [tmeio, tsup]
    end
    
    tmeio = (tsup+tinf)/2;                                      % Calcula o ponto m�dio do novo intervalo de busca
    [u,teta2max_meio] = prog_lin(A,b,c,qmax,tmeio,n);    % Calcula o alcance para o ponto m�dio
end

tmin = tmeio;
umin = u;