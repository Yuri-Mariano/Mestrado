function gama=calcgama(k,i,A,b,tf,n);
% Dados k, i, A, b, tf e n, esta fun��o calcula \gamma_k(i)

deltat = tf/n;
ti1 = (i-1)*deltat;
ti  = i*deltat;
tk  = k*deltat;

expi1 = expm(A*(tk-ti1));
expi  = expm(A*(tk-ti));

gama = (expi1-expi)*inv(A)*b;