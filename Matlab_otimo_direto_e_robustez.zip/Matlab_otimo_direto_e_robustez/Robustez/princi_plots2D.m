% Programa para avalia��o da robustez do controle �timo
% 

close all
clear all
clc
tic


cor = [1 0 0;   % Vermelho
       0 0 1;   % Azul
       1 0.5 0; % Laranja
       1 0 1;   % Roxo
       0 0.5 0; % Verde escuro
       0 0.75 1;% Azul claro
       0 1 1;   % Ciano
       0 1 0;   % Verde
       0 0 0];  % Preto

%==========================================================================
%                           DADOS DE ENTRADA
%==========================================================================

% Define os par�metros do modelo nominal

    K0 = 0.5;
    T1 = 180;
    T2 = 30;

% Define valores dos demais par�metros do problema

    qmax   = 500;                       % Pot�ncia m�xima do aquecedor
    n      = 100;                       % N�mero de pontos da discretiza��o para a otimiza��o
    teta2_desejado = 120;               % Temperatura final desejada
    eps_tmin = 0.1;                     % Crit�rio de parada (precis�o da solu��o)
    
    delta = [0 0.05 0.1 0.2];           % Vetor com valores de delta (folga em rela��o ao valor m�ximo da pot�ncia)             
    eps = [0.01 0.05 0.1 0.15];         % Vetor com valores de eps (erro param�trico)
   
     %delta = [0.2];           % Vetor com valores de delta (folga em rela��o ao valor m�ximo da pot�ncia)             
     %eps = [0.05];         % Vetor com valores de eps (erro param�trico)
    
    %   ===   DADOS PARA O PARALELEP�PEDO   ===
    
    parale_ou_MCarlo = 1;               % Gera K0, T1 e T2 numa grade do paralelep�pedo
    m = 3; %5                             % N�mero de pontos de cada aresta do paralelep�pedo
                                        % Note que, quando m = 2, s�o usados apenas os v�rtices do paralelep�pedo
    n_aval_tripl = m^3;                 % Numero de avalia��es para cada valor de eps para o paralelep�pedo
    
     %   ===   DADOS PARA O MONTE CARLO   ===
    
        parale_ou_MCarlo = 2;               % Gera K0, T1 e T2 aleatoriamente (Monte Carlo)
        n_aval_tripl = 1000;     %100             % N�mero de avalia��es para cada valor de eps para Monte Carlo
     
     
%==========================================================================
%                       CALCULA PAR�METROS DO PID-SIMC
%==========================================================================

% Ajusta T (par�metro de sintonia do PID-SIMC)

T = T2/100;    % Este parece ser um bom valor de T

% Calcula par�metros do PID-SIMC

[Kc,tauI,tauD] = PID_SIMC(K0,T1,T2,T);

% Transforma os ganhos para a forma do PID do Matlab (Paralela)

KP   = Kc*(1+tauD/tauI);
KI   = Kc/tauI;
KD   = Kc*tauD;
NPID = 1; %100;

% Resolve o problema de tempo m�nimo nominal para qmax

[tmin,umin,A,b,c]=tempo_minimo(K0,T1,T2,qmax,n,eps_tmin,teta2_desejado);
     
vetor_tmin = [tmin];

%==========================================================================
%                               VARIA qmax
%==========================================================================

for idelta=1:length(delta),
    
    idelta
    
    qmax_atual = (1-delta(idelta))*qmax;
     if K0*qmax_atual < teta2_desejado,
        display('Problema n�o tem solu��o para o valor de pot�ncia a seguir:')
        qmax_atual
     end
     
     lim_sup_satur_PID = qmax-qmax_atual;   % Par�metro para anti-windup
     meio_qmax_atual = qmax_atual/2;        % Par�metro p/ sele��o do PID
     
     %=====================================================================
     %             RESOLVE O PROBLEMA DE TEMPO M�NIMO (nominal)
     %=====================================================================

     [tmin,umin,A,b,c]=tempo_minimo(K0,T1,T2,qmax_atual,n,eps_tmin,teta2_desejado);
     
     vetor_tmin = [vetor_tmin tmin];
     
     % Prepara dados para o simulador
     
     [tempo,potencia,tXu] = preproc_simulacao(tmin,umin,n);
     
     % Simula
     
     dt = tmin/100;
     sim('simulador_controle_otimo')
     
     % Prepara entrada de refer�ncia para o Simulink (malha fechada)
     
     t_otimoXteta2_otimo = [t_otimo teta2_otimo];
         
     %=====================================================================
     %                      VARIA O ERRO NOS PAR�METROS
     %=====================================================================
     
     for ieps =1:length(eps),
         
         ieps
              
         eps_atual = eps(ieps);
                
         erro_final_eps    = -1;
         tetapto_final_eps = -1;
                         
         for i_aval_tripl = 1:n_aval_tripl,
                    
            % Gera os valores atuais de K0, T1 e T2

            if parale_ou_MCarlo == 1,    % Grade no paralelep�pedo
                [K0_atual,T1_atual,T2_atual] = gera_K0_T1_T2_grade_paralelo(K0,T1,T2,eps_atual,m,i_aval_tripl);
            else                         % Aleat�rio (Monte Carlo)
                [K0_atual,T1_atual,T2_atual] = gera_K0_T1_T2_random(K0,T1,T2,eps_atual);
            end

            % Simula o sistema em malha fechada
            
            T1T2 = T1_atual*T2_atual;
            A21_atual = 1/T1T2;
            A22_atual = (T1_atual+T2_atual)/T1T2;
            b2_atual  = K0_atual/T1T2;

            sim('simulador_malha_fechada_PID_com_Anti_Windup')

            % Salva o valor do erro final

            erro_final_atual = abs(teta2_malha_fechada(length(teta2_malha_fechada))-teta2_desejado);
            if erro_final_atual > erro_final_eps,
                erro_final_eps = erro_final_atual;
            end
            
            tetapto_atual = abs(tetapto2_malha_fechada(length(tetapto2_malha_fechada)));
            if tetapto_atual > tetapto_final_eps,
                tetapto_final_eps = tetapto_atual;
            end
                    
         end

         
         tab_erro_final(idelta,ieps)    = erro_final_eps;
         tab_tetapto_final(idelta,ieps) = tetapto_final_eps;
                 
     end
       
end

% Plota o valor de tmin para os diversos valores de delta

figure

plot([0 delta],vetor_tmin,'b')  % >>>>>>>>>>>>>>>>>>>>   PODE PLOTAR DUAS VEZES PARA delta = 0
xlabel('\Delta')
ylabel('Tempo m�nimo (s)')
hold on
grid
plot([0],[vetor_tmin(1)],'*',[0],[vetor_tmin(1)],'O','Color',cor(1,:))
for idelta = 1:length(delta),
    plot(delta(idelta),vetor_tmin(idelta+1),'*',delta(idelta),vetor_tmin(idelta+1),'O','Color',cor(idelta,:))
end

% Para cada delta, plota o erro final m�ximo em fun��o de eps

for idelta=1:length(delta),
    
    if idelta == 1,
        figure
        plot(eps,tab_erro_final(1,:),eps,tab_erro_final(1,:),'*','Color',cor(1,:))
        xlabel('\epsilon')
        ylabel('Erro final m�ximo (^oC)')
        grid
        hold on
     end
     
     if idelta ~= 1,
         plot(eps,tab_erro_final(idelta,:),eps,tab_erro_final(idelta,:),'*','Color',cor(idelta,:))
     end
    
end

% Para cada delta, plota o tetapto final em fun��o de eps

for idelta=1:length(delta),
    
    if idelta == 1,
        figure
        plot(eps,tab_tetapto_final(1,:),eps,tab_tetapto_final(1,:),'*','Color',cor(1,:))
        xlabel('\epsilon')
        ylabel('Teta ponto final m�ximo (^oC/s)')
        grid
        hold on
     end
     
     if idelta ~= 1,
         plot(eps,tab_tetapto_final(idelta,:),eps,tab_tetapto_final(idelta,:),'*','Color',cor(idelta,:))
     end
    
end
toc