function [u,teta2max] = prog_lin(A,b,c,qmax,tf,n);
% Esta fun��o resolve um passo da busca da solu��o do problema de controle
% �timo por meio da Programa��o LKinear

% C�lculo dos coeficientes da fun��o objetivo

f = [];
temp = [];

for i=1:n,
   gama_n_i = calcgama(n,i,A,b,tf,n);
   f = [f -gama_n_i(1)];
   temp=[temp gama_n_i];
end

aux = A*temp;
Aeq = aux(1,:);
Aeq(n) = Aeq(n) + b(1);

beq = 0;

% Limites inferior e superior da vari�vel de controle

LB = zeros(n,1);
UB = qmax*ones(n,1);

% Resolve o PPL

options = optimset('MaxIter',1000);
%[u,teta2max] = linprog(f,Ades,bdes,Aeq,beq,LB,UB,[],options);
[u,teta2max,exitflag] = linprog(f,[],[],Aeq,beq,LB,UB,[],options);
if exitflag ~= 1
    display('PL n�o convergiu!')
end
teta2max = -teta2max;