% Programa principal para o problema de controle �timo direto - sem
% otimiza��o expl�cita - em que o objetivo � determinar o instante
% de desligamento (tS) do resistor para que a temperatura atinja o valor
% desejado com derivada nula. 
%

%=========================================================================

close all
clear all

% Dados do problema

K = 0.5;        % Ganho do processo em baixas frequ�ncias
T1 = 30;        % Constante de tempo do processo
T2 = 180;       % Constante de tempo do processo

umax = 500;     % Pot�ncia m�xima

teta_des = 120; % Temperatura desejada

%=========================================================================


teta_0 = 0;    % Temperatura inicial
teta_pto_0 = 0;% Derivada inicial da temperatura

y0 = teta_0;
ypto0 = teta_pto_0;

% Crit�rio de parada do m�todo de busca da solu��o

eps = 0.001;

% Teste de consist�ncia dos dados

teta_regime = K*umax;

if teta_regime < teta_des
    display('Temperatura desejada incompativel com a pot�ncia dispon�vel.');
end

% Inicializa��o de vari�veis auxiliares

T1T2T1T2 = T1*T2/(T1-T2);
T1T2T2T1 = T1*T2/(T2-T1);
T1T1T2   = T1/(T1-T2);
T2T2T1   = T2/(T2-T1);
T1T2T1   = T1/(T2-T1);
T2T1T2   = T2/(T1-T2);
invT1T2  = 1/(T1-T2);
invT2T1  = 1/(T2-T1);

% Inicializa��o do processo de busca

minT = min([T1 T2]);
maxT = max([T1 T2]);

Tinf = minT;    % Hip�tese: para T=Tinf a temperatura desejada n�o � alcan�ada 
Tsup = 10*maxT;  % Hip�tese: para T=Tsup a temperatura desejada � ultrapassada

while Tsup-Tinf > eps
   
    tS = (Tinf+Tsup)/2;
    
    exp1 = exp(-tS/T1);    
    exp2 = exp(-tS/T2);
    
    ytau0 = (T1T2T1T2*ypto0+T1T1T2*y0)*exp1+(T1T2T2T1*ypto0+T2T2T1*y0)*exp2;
    ytau0 = ytau0 + K*umax*(1+T1T2T1*exp1+T2T1T2*exp2);
    
    yptotau0 = -(T2T1T2*ypto0+invT1T2*y0)*exp1-(T1T2T1*ypto0+invT2T1*y0)*exp2;
    yptotau0 = yptotau0-K*umax*(invT2T1*exp1+invT1T2*exp2);
    
    tau_aster = T1T2T1T2*log((T1*yptotau0+ytau0)/(T2*yptotau0+ytau0));
    
    exp1 = exp(-tau_aster/T1);
    exp2 = exp(-tau_aster/T2);
    teta_aster = (T1T2T1T2*yptotau0+T1T1T2*ytau0)*exp1;
    teta_aster = teta_aster + (T1T2T2T1*yptotau0+T2T2T1*ytau0)*exp2;
    
    if teta_aster > teta_des
        Tsup = tS;
    else 
        Tinf = tS;
    end
    
end

tS

% C�lculo da solu��o no tempo para plotagem

t_final = tS+tau_aster;
dt = t_final/200;
vetor_t=0:dt:t_final;
vetor_teta = [];

exp1 = exp(-tS/T1);    
exp2 = exp(-tS/T2);

ytau0 = (T1T2T1T2*ypto0+T1T1T2*y0)*exp1+(T1T2T2T1*ypto0+T2T2T1*y0)*exp2;
ytau0 = ytau0 + K*umax*(1+T1T2T1*exp1+T2T1T2*exp2);

yptotau0 = -(T2T1T2*ypto0+invT1T2*y0)*exp1-(T1T2T1*ypto0+invT2T1*y0)*exp2;
yptotau0 = yptotau0-K*umax*(invT2T1*exp1+invT1T2*exp2);

for i=1:length(vetor_t),
    
    if vetor_t(i) <= tS
        
        exp1 = exp(-vetor_t(i)/T1);
        exp2 = exp(-vetor_t(i)/T2);
    	yi = (T1T2T1T2*ypto0+T1T1T2*y0)*exp1;
        yi = yi + (T1T2T2T1*ypto0+T2T2T1*y0)*exp2;
        yi = yi + K*umax*(1+T1T2T1*exp1+T2T1T2*exp2);
        
    else
        
        exp1 = exp(-(vetor_t(i)-tS)/T1);
        exp2 = exp(-(vetor_t(i)-tS)/T2);
        yi = (T1T2T1T2*yptotau0+T1T1T2*ytau0)*exp1;
        yi = yi + (T1T2T2T1*yptotau0+T2T2T1*ytau0)*exp2;

    end
     
    vetor_teta = [vetor_teta yi];
    
end

load t
load teta2
teta2 = teta2-30; % Corre��o porque a solu��o via PL considerava a temperatura ambiente de 30 oC


plot(vetor_t,vetor_teta,'b',t,teta2,'r','LineWidth',2)
legend('Controle �timo direto','Controle �timo via PL','Location','SouthEast')
grid
xlabel('Tempo (s)')
ylabel('Temperatura (^oC)')

hold on

plot(vetor_t(length(vetor_t)),vetor_teta(length(vetor_teta)),'b*')
plot(t(length(t)),teta2(length(teta2)),'ro')

hold off
