% Limpa vari�veis, fecha janelas, limpa tela e inicia contador

clear all
close all
clc
tic

k=0.5;
tal1=30;
tal2=180;
%tal1=100;
%tal2=100;
umax=500;
T=50; % temperatura desejada
T=120;
c=1; %toler�ncia
c=c/100;
tot=0;

if tal1 > tal2
  tfiM = 10*tal1;
  tfim = 0.5*tal2;
elseif tal2 > tal1
  tfiM = 10*tal2;
  tfim = 0.5*tal1;
else
  %erro = 1
  tfiM = 10*tal1;
  tfim = 0.5*tal2;
endif


%tfi = tfiM/2;
tfi = (tfiM-tfim)/2;
%tfi=1.26215;

%tfi=1

[tot] = maximiza (k,tal1,tal2,tfi,umax)
dif = abs((T-tot)/T);
tfii=0;
%tfii=tfim
%tfis=tfiM;

tfia1=tfi;
tfia2=0;

am=0;
amk=am;
tfik=tfi;
totk=tot;

while (dif > c)
  
%  [tot] = maximiza (k,tal1,tal2,tfi);
  dif = abs((T-tot)/T);

  if dif < c
    tot;
    tfi;
    
  elseif tot > T
    
    tfi = tfi - abs(tfia2-tfia1)/2;

    
  else
    
    tfi = tfi + abs(tfia2-tfia1)/2;

  
    endif
  

    [tot] = maximiza (k,tal1,tal2,tfi,umax);
    tfia2 = tfia1;
    tfia1 = tfi;
  
  am=am+1;
  amk=[amk am];
  tfik=[tfik tfi];
  totk=[totk tot];
  
endwhile


figure(1)
plot(amk,tfik)

figure(2)
plot(amk,totk)

plot_result_final (k,tal1,tal2,tfi,umax)

toc