function plot_result_final(k,tal1,tal2,tfi,umax)

##% Limpa vari�veis, fecha janelas, limpa tela e inicia contador
##
##clear all
##close all
##clc
##tic

% Carrega pacotes de controle e sinais

%pkg load control
%pkg load signal

% Define valores para as vari�veis

%k=0.5;
%tal1=30;
%tal2=180;
t0=0;
x0=[0 0]';
umin=0;
%umax=500;
n=100;
%tfi=94.922;
%tfi=95;
dt=tfi/n;

%tfi=1.262149810791016;

% Etapa 1 - Fun��o de transfer�ncia

% Calcula par�metros para a fun��o de transfer�ncia

a=tal1*tal2;
b=(tal1+tal2);
c=1;
  
% Calcula matrizes Espa�o de estados

% feito a m�o: (acertar no texto)

A=[0 1 ; -1/a -b/a];
B=[0 k/a]';
C=[1 0];
D=[0];

% Calcula autovalores de A

p1=eig(A)(1);
p2=eig(A)(2);

% C�lculo das constantes k1... k8

a11=A(1,1);
a12=A(1,2);
a21=A(2,1);
a22=A(2,2);

k1=(a11-p2)/(p1-p2);
k2=1-(a11-p2)/(p1-p2);
k3=(a12)/(p1-p2);
k4=-(a12)/(p1-p2);
k5=(a21)/(p1-p2);
k6=-(a21)/(p1-p2);
k7=(a22-p2)/(p1-p2);
k8=1-(a22-p2)/(p1-p2);

% C�lculo da integral da exponencial e gama para i valores

% inicializa vari�veis

x=[0 0]';
xa=[0 0]';
tf=[0];
lb=[];
ub=[];
gn=[];
vartypei=[];

% c�lculos variando de 1 a n

for i=1:n
  iep1n=-(1/p1)*exp(p1*n*dt)*(exp(-p1*i*dt)-exp(-p1*(i-1)*dt));
  iep2n=-(1/p2)*exp(p2*n*dt)*(exp(-p2*i*dt)-exp(-p2*(i-1)*dt));
  ifittaln=[k1*iep1n+k2*iep2n k3*iep1n+k4*iep2n ; k5*iep1n+k6*iep2n k7*iep1n+k8*iep2n];
  g=ifittaln*B;
  gn=[gn g];
  xa=[xa+g];
  x=[x xa];
  tf=[tf i*dt];
  lb=[lb umin];
  ub=[ub umax];
  vartypei=char(vartypei,char(67));
end

% Prepara vari�veis para otimiza��o

vartype=vartypei(2:(n+1))';

xp1=[x(1,:)];
xp2=[x(2,:)];

gn1=gn(1,:);
gn2=gn(2,:);

c=gn(1,:)';
a=gn(2,:);
b=[0];

ctype="S"; % Sentido de cada restri��o
s=-1; 
[uot,tot]=glpk(c,a,b,lb,ub,ctype,vartype,s);

% Apresenta��o de resultados

% Calcula Fi para um dt 

fidt=[k1*exp(p1*dt)+k2*exp(p2*dt) k3*exp(p1*dt)+k4*exp(p2*dt) ; k5*exp(p1*dt)+k6*exp(p2*dt) k7*exp(p1*dt)+k8*exp(p2*dt)]; % novo
  
% Inicializa vari�veis
 
ud=[];
xdk=[0 0]';
xotkf=[0 0]';
tp=[0];
xk0=x0;

% Calcula valores para apresenta��o
 
for k=1:n
  t=k*dt;
  tp=[tp t];
  
  ud=[ud umax];
  iep1d=-(1/p1)*exp(p1*k*dt)*(exp(-p1*k*dt)-1);
  iep2d=-(1/p2)*exp(p2*k*dt)*(exp(-p2*k*dt)-1);
  ifi0tf=[k1*iep1d+k2*iep2d k3*iep1d+k4*iep2d ; k5*iep1d+k6*iep2d k7*iep1d+k8*iep2d];
  xd=ifi0tf*B*ud(k);
  xdk=[xdk xd];
  
  iep1k=-(1/p1)*exp(p1*k*dt)*(exp(-p1*k*dt)-exp(-p1*(k-1)*dt));
  iep2k=-(1/p2)*exp(p2*k*dt)*(exp(-p2*k*dt)-exp(-p2*(k-1)*dt));
  ifittalk=[k1*iep1k+k2*iep2k k3*iep1k+k4*iep2k ; k5*iep1k+k6*iep2k k7*iep1k+k8*iep2k];
  xotk=ifittalk*B*uot(k);
  xotk=fidt*xk0+xotk; % novo
  xk0=xotk;  
  xotkf=[xotkf xotk]; % novo
    
 end
 
% Prepara vari�veis para serem plotadas

temp_d=[xdk(1,:)];
temp_d_p=[xdk(2,:)];

temp_ot=[xotkf(1,:)]; % novo
temp_ot_p=[xotkf(2,:)]; % novo

ud_pl=[ud ud(n)];
uot_pl=[uot;uot(n)]';

% Plotagens

##figure (1)
##plot(tp,temp_d,'b',tp,temp_d_p,'g',tp,ud_pl,'r')
##
##figure (2) 
##plot(tp,temp_ot,'b',tp,temp_ot_p,'g',tp,uot_pl,'r') % novo

figure(3)
plot(tp,uot_pl)

figure(4)
plot(tp,temp_ot)

figure(5)
plot(tp,temp_ot_p)

toc