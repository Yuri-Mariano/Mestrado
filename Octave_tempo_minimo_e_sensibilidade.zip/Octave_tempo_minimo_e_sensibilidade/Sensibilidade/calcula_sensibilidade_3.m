function [uot,temp_ot,temp_ot_p,A,B] = calcula_sensibilidade_3 (k,tal1,tal2,tfi,umax)

t0=0;
x0=[0 0]';
umin=0;
n=100;
dt=tfi/n;

% Etapa 1 - Fun��o de transfer�ncia

% Calcula par�metros para a fun��o de transfer�ncia

a=tal1*tal2;
b=(tal1+tal2);
c=1;
  
% Calcula matrizes Espa�o de estados

% feito a m�o: (acertar no texto)

A=[0 1 ; -1/a -b/a];
B=[0 k/a]';
C=[1 0];
D=[0];

% C�lculo da integral da exponencial e gama para i valores

% inicializa vari�veis

x=[0 0]';
xa=[0 0]';
tf=[0];
lb=[];
ub=[];
gn=[];
vartypei=[];

% c�lculos variando de 1 a n

for i=1:n
  
  g=(expm(A*(tfi-(i-1)*dt))-expm(A*(tfi-i*dt)))*inv(A)*B;
  gn=[gn g];

  %tf=[tf i*dt]
  lb=[lb umin];
  ub=[ub umax];
  vartypei=char(vartypei,char(67));
end

% Prepara vari�veis para otimiza��o

vartype=vartypei(2:(n+1))';

gn1=gn(1,:);
gn2=gn(2,:);

c=gn(1,:)';
a=gn(2,:);
b=[0];

ctype="S"; % Sentido de cada restri��o
s=-1; 
[uot,tot]=glpk(c,a,b,lb,ub,ctype,vartype,s);

% Apresenta��o de resultados

% Inicializa vari�veis
 
ud=[];
xdk=[0 0]';
xdka=[0 0]';
xotk=[0 0]';
xotkf=[0 0]';
tp=[0];
xk0=x0;

% Calcula valores para apresenta��o
 
for k=1:n
  t=k*dt;
  tp=[tp t];
  
  ud=[ud umax];
  g=(expm(A*(t-(k-1)*dt))-expm(A*(t-k*dt)))*inv(A)*B;
  
  xd=g*ud(k);
  xdka=[xdka+xd];
  xdk=[xdk xdka];

  xot=g*uot(k);
  xot=expm(A*dt)*xk0+xot;
  xk0=xot;
  xotkf=[xotkf xot]; % novo
    
   
 end
 
% Prepara vari�veis para serem plotadas

temp_d=[xdk(1,:)];
temp_d_p=[xdk(2,:)];

temp_ot=[xotkf(1,:)]; % novo
temp_ot_p=[xotkf(2,:)]; % novo

ud_pl=[ud ud(n)];
uot_pl=[uot;uot(n)]';

% Plotagens

##figure(3)
##plot(tp,uot_pl)
##
##figure(4)
##plot(tp,temp_ot)
##
##figure(5)
##plot(tp,temp_ot_p)
##
##figure(6)
##plot(tp,temp_d)

toc