% Limpa vari�veis, fecha janelas, limpa tela e inicia contador

clear all
close all
clc
tic

% Carrega pacotes de controle e sinais

%pkg load control
%pkg load signal

% Define valores para as vari�veis
% Par�metros do modelo

kn=0.5;
tal1n=30;
tal2n=180;

% Demais dados do problema

t0=0;
x0=[0 0]';
umin=0;
umax=500;
n=100;
tfi=94.827;
%tfi=95.1738; % pelo programa do professor
%tfi=163.07;
tfi=162.11;
dt=tfi/n;

vtal1=1;
vtal2=0;
vk=0;


tal1=tal1n*(1+vtal1/100);
tal2=tal2n*(1+vtal2/100);
k0=kn*(1+vk/100);

[uot,temp_ot,temp_ot_p,A,B] = calcula_sensibilidade_3 (k0,tal1,tal2,tfi,umax);
[uotn,temp_otn,temp_ot_pn,An,Bn] = calcula_sensibilidade_3 (kn,tal1n,tal2n,tfi,umax);

% Sensibilidade

% Vari�veis de base2dec

tetaB = temp_ot(n+1);
tetaBn = temp_otn(n+1);
##teta_p_Bn = temp_ot_pn(n+1);
##teta_p_B = temp_ot_p(n+1);
teta_p_Bn = tetaBn/tfi;
teta_p_B = tetaB/tfi;
tal1B = tal1n;
tal2B = tal2n;
kB = kn;

% Calcula matrizes aumentadas

dAdtal1 = [0 0 ; 1/((tal1n^2)*tal2n) 1/(tal1n^2)];
dAdtal2 = [0 0 ; 1/(tal1n*(tal2n^2)) 1/(tal2n^2)];

dBdtal1 = [0 ; -kn/((tal1n^2)*tal2n)];
dBdtal2 = [0 ; -kn/(tal1n*(tal2n^2))];
dBdk = [0 ; 1/(tal1n*tal2n)];

z=zeros(2,2);

Aa = [An z z z ; dAdtal1 An z z ; dAdtal2 z An z ; z z z An];
Ba = [Bn ; dBdtal1 ; dBdtal2 ; dBdk];

% C�lculo da integral da exponencial e gama para i valores

% inicializa vari�veis

xs=[0 0 0 0 0 0 0 0]';
xsa=[0 0 0 0 0 0 0 0]';
ge=[];
xs=[];

% c�lculos variando de 1 a n

for j=1:n
  g=(expm(Aa*(tfi-(j-1)*dt))-expm(Aa*(tfi-j*dt)))*inv(Aa)*Ba;
  ge=[ge g];
  
  %gu=g*uotn(j);
  %ge=[ge gu];
  %xsa=[xsa+gu];
  %xs=[xs xsa];
end

xsa=ge*uotn;

% Sensibilidades em unidades de engenharia

x1=[xsa(1)];
x2=[xsa(2)];
x3=[xsa(3)];
x4=[xsa(4)];
x5=[xsa(5)];
x6=[xsa(6)];
x7=[xsa(7)];
x8=[xsa(8)];

% Sensibilidades normalizadas

sn3=x3*tal1B/tetaBn
sn4=x4*tal1B/teta_p_Bn
sn5=x5*tal2B/tetaBn
sn6=x6*tal2B/teta_p_Bn
sn7=x7*kB/tetaBn
sn8=x8*kB/teta_p_Bn

##sn3p=sn3*100
##sn4p=sn4*100
##sn5p=sn5*100
##sn6p=sn6*100
##sn7p=sn7*100
##sn8p=sn8*100


var_temp = 100*(tetaB-tetaBn)/tetaBn
var_temp_p = 100*(teta_p_B-teta_p_Bn)/teta_p_Bn


toc